function sigma() {
    alert("Hello world!");
    console.log("Hello world!");
}